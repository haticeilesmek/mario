-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 09 Haz 2024, 19:38:09
-- Sunucu sürümü: 10.4.28-MariaDB
-- PHP Sürümü: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `mario_website`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `contents`
--

CREATE TABLE `contents` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `contents`
--

INSERT INTO `contents` (`id`, `title`, `content`, `image_url`) VALUES
(1, 'Bilgilendirme', '', 'https://i.hizliresim.com/eb7qglr.png'),
(2, 'Sigaranın Zararları', 'Sigara içmek, vücutta hemen hemen her organı etkileyerek ciddi sağlık sorunlarına neden olur. İşte sigaranın insan sağlığına olan başlıca zararları:\n\n<font color=\"red\"><b><h2>Kanser<br></b></h2> </font>\n<li>Akciğer Kanseri: Sigara, akciğer kanserinin en büyük nedenidir. Akciğer kanserine yakalanma riski, sigara içenlerde içmeyenlere göre çok daha yüksektir.</li>\n<li>Diğer Kanser Türleri: Sigara, ağız, gırtlak, yemek borusu, pankreas, böbrek, mesane ve rahim ağzı kanseri gibi diğer birçok kanser türüne de neden olabilir.</li>\n<br>\n<font color=\"red\"><b><h2>Kalp ve Damar Hastalıkları<br></b></h2> </font>\n<li>Koroner Kalp Hastalığı: Sigara içmek, kalp krizi riskini artırır. Sigara, kan damarlarının daralmasına ve kalp kasına kan akışının azalmasına neden olur.</li>\n<li>Felç: Sigara, beyin damarlarının daralmasına yol açarak felç riskini artırır.</li>\n<li>Periferik Arter Hastalığı: Sigara, bacaklara ve kollara kan akışını engelleyerek periferik arter hastalığına neden olabilir.</li>\n<br>\n<font color=\"red\"><b><h2>Solunum Sistemi Hastalıkları<br></b></h2> </font>\n<li>Kronik Obstrüktif Akciğer Hastalığı (KOAH): Sigara içmek, kronik bronşit ve amfizem gibi KOAH türlerine yol açar. KOAH, solunum yetmezliğine neden olabilir.</li>\n<li>Astım: Sigara, astım ataklarını tetikleyebilir ve astım semptomlarını kötüleştirebilir.</li>\n<br>\n<font color=\"red\"><b><h2>Gebelik ve Doğurganlık<br></b></h2> </font>\n<li>Düşük ve Erken Doğum: Sigara içmek, hamilelik sırasında düşük yapma ve erken doğum riskini artırır.</li>\n<li>Doğum Kusurları: Sigara, bebeğin gelişimini olumsuz etkileyerek doğum kusurlarına yol açabilir.</li>\n<li>Düşük Doğum Ağırlığı: Sigara içen annelerin bebekleri genellikle düşük doğum ağırlığı ile doğar.</li>\n<br>\n<font color=\"red\"><b><h2>Bağışıklık Sistemi<br></b></h2> </font>\n<li>Zayıflamış Bağışıklık Sistemi: Sigara içmek, bağışıklık sistemini zayıflatarak enfeksiyonlara karşı direnci azaltır.</li>\n<li>Yaraların Geç İyileşmesi: Sigara, yaraların ve cerrahi kesilerin daha yavaş iyileşmesine neden olabilir.</li>\n<br>\n<font color=\"red\"><b><h2>Cilt ve Diş Sağlığı<br></b></h2> </font>\n<li>Erken Cilt Yaşlanması: Sigara, cildin elastikiyetini kaybetmesine ve erken kırışıklıkların oluşmasına neden olur.</li>\n<li>Diş ve Diş Eti Hastalıkları: Sigara, dişlerin sararmasına, diş eti hastalıklarına ve diş kaybına yol açabilir.</li><br>\n<br>\n<font color=\"red\"><b><h2>Genel Sağlık<br></b></h2> </font>\n<li>Kemik Sağlığı: Sigara içmek, kemik yoğunluğunu azaltarak osteoporoz riskini artırır.</li></li>\n<li>Göz Sağlığı: Sigara, katarakt ve yaşa bağlı makula dejenerasyonu gibi göz hastalıklarına neden olabilir.\n<li>Sindirim Sistemi: Sigara, mide ve bağırsak hastalıklarına yol açabiir.</li><br>\n<br>\nSigaranın zararları sadece içicilerle sınırlı değildir. Pasif içiciler, yani sigara dumanına maruz kalan kişiler de benzer sağlık riskleri taşırlar. Bu nedenle, sigara içmek hem bireyin kendisi hem de çevresindeki insanlar için büyük bir sağlık tehdididir. Sigarayı bırakmak, sağlığın iyileşmesi ve yaşam kalitesinin artması açısından son derece önemlidir.', NULL),
(3, 'Sigaranın İçeriği', 'Sigara, çeşitli kimyasal maddeler içeren ve ciddi sağlık sorunlarına yol açan bir üründür. İçerisinde bulunan başlıca maddeler ve zararları şunlardır: <br>\n\n<font color=\"red\"><b><h2>Nikotin <br> </b></h2> </font>\n<li>Bağımlılık: Nikotin, sigaranın en bağımlılık yapıcı maddesidir. Beyindeki ödül sistemini etkileyerek bağımlılık yaratır. </li>\n<li>Kalp ve Damar Hastalıkları: Nikotin, kalp atış hızını ve kan basıncını artırarak kalp ve damar hastalıkları riskini yükseltir. </li>\n<br>\n<font color=\"red\"><b><h2>Karbon Monoksit <br> </b></h2> </font>\n<li>Solunum Problemleri: Karbon monoksit, oksijenin kanda taşınmasını engelleyerek vücut dokularına yeterli oksijen ulaşmasını zorlaştırır. Bu da solunum problemlerine yol açar. </li>\n<li>Kalp Hastalıkları: Karbon monoksit, kalp ve damar sağlığını olumsuz etkileyerek kalp krizi riskini artırır.</li>\n<br>\n<font color=\"red\"><b><h2>Katran<br> </b></h2> </font>\n<li>Kanser: Katran, akciğer, gırtlak, yemek borusu ve diğer organlarda kansere yol açabilen kanserojen maddeler içerir.</li>\n<li>Solunum Sistemi Hasarı: Katran, akciğerlerde birikerek kronik bronşit ve amfizem gibi solunum yolu hastalıklarına neden olur.</li>\n<br>\n<font color=\"red\"><b><h2>Formaldehit<br> </b></h2> </font>\n<li>Kanser: Formaldehit, kanserojen bir madde olup uzun süreli maruziyet durumunda kanser riskini artırır.</li>\n<li>Solunum Sistemi Tahrişi: Formaldehit, burun, boğaz ve gözlerde tahrişe yol açar.</li>\n<br>\n<font color=\"red\"><b><h2>Benzopiren<br> </b></h2> </font>\n<li>Kanser: Benzopiren, güçlü bir kanserojen olup DNA hasarına neden olarak kanser gelişimini teşvik eder.</li>\n<br>\n<font color=\"red\"><b><h2>Aseton<br> </b></h2> </font>\n<li>Solunum Sistemi Tahrişi: Aseton, solunum yollarını tahriş edebilir ve uzun süreli maruziyet durumunda solunum yolu hastalıklarına yol açabilir.</li>\n<br>\n<font color=\"red\"><b><h2>Kurşun ve Kadmiyum<br> </b></h2> </font>\n<li>Toksisite: Bu ağır metaller, böbrek hasarı, kemik erimesi ve nörolojik hasar gibi ciddi sağlık sorunlarına neden olabilir.</li>\n<br>\n<font color=\"red\"><b><h2>Hidrojen Siyanür<br> </b></h2> </font>\n<li>Zehirlenme: Hidrojen siyanür, solunum sistemini etkileyerek zehirlenmeye neden olabilir.</li>\n<br>\n<font color=\"red\"><b><h2>Arsenik<br> </b></h2> </font>\n<li>Kanser ve Zehirlenme: Arsenik, kanserojen özelliklere sahip olup zehirlenme belirtileri gösterebilir.</li>\n<br>\n<font color=\"red\"><b><h2>Amonyak<br> </b></h2> </font>\n<li>Solunum Sistemi Tahrişi: Amonyak, solunum yollarını tahriş ederek öksürük, nefes darlığı ve boğaz ağrısına neden olabilir.</li>\n<br>\nBu maddeler, sigara içmenin sadece bir kısmıdır ve her biri ciddi sağlık sorunlarına yol açabilir. Sigara içmenin, başta kanser, kalp hastalıkları ve solunum yolu hastalıkları olmak üzere <br>birçok ciddi hastalığın başlıca nedenlerinden biri olduğu unutulmamalıdır. Sağlık üzerindeki bu zararlı etkiler, sigara içen bireylerin yanı sıra pasif içiciler için de geçerlidir.<br>', NULL),
(4, 'Sigarayı Bırakma Yolları', '\nSigarayı bırakmak zor olabilir, ancak birçok yöntem ve destek mekanizması mevcuttur. İşte bazı etkili sigarayı bırakma yolları:  <br>\n<br>\n<font color=\"red\"><b><h2>1. Kendi Kendine Bırakma<br></b></h2> </font>\nHazırlık: Bırakma tarihini belirleyin ve bu tarihe kadar hazırlık yapın.<br>\nTetikleyicilerden Kaçınma: Sigarayı hatırlatan durum ve alışkanlıklardan uzak durun.<br>\nSağlıklı Alternatifler: El ve ağız alışkanlıklarınızı sağlıklı alternatiflerle değiştirin, örneğin su içmek veya sakız çiğnemek.<br>\n<br>\n<font color=\"red\"><b><h2>2. Destek Grupları<br></b></h2> </font>\nDestek Almak: Arkadaşlar, aile ve destek grupları, bırakma sürecinde moral ve motivasyon sağlar.<br>\nDanışmanlık: Profesyonel danışmanlık hizmetleri, davranış değişikliklerini destekler.<br>\n<br>\n<font color=\"red\"><b><h2>3. Nikotin Replasman Tedavisi (NRT)<br></b></h2> </font>\nNikotin Sakızı veya Pastilleri: Nikotin ihtiyacınızı azaltır ve yoksunluk belirtilerini hafifletir.<br>\nNikotin Bantları: Cilde yapıştırılan bantlar, düzenli olarak nikotin sağlar.<br>\n<br>\n<font color=\"red\"><b><h2>4. İlaç Tedavisi<br></b></h2> </font>\nReçeteli İlaçlar: Bupropion ve varenicline gibi ilaçlar, nikotin yoksunluğu belirtilerini azaltarak bırakmayı kolaylaştırır.<br>\n<br>\n<font color=\"red\"><b><h2>5. Davranışsal Terapi<br></b></h2> </font>\nBilişsel Davranışçı Terapi (BDT): Sigara içme alışkanlıklarını tanımlayarak, bu davranışları değiştirmeye yardımcı olur.<br>\n<br>\n<font color=\"red\"><b><h2>6. Elektronik Sigara<br></b></h2> </font>\nAlternatif Olarak Kullanma: Bazı insanlar, nikotin alımını azaltmak için e-sigaraları kullanır, ancak e-sigaraların uzun vadeli sağlık etkileri hakkında daha fazla araştırma gereklidir.<br>\n<br>\n<font color=\"red\"><b><h2>7. Fiziksel Aktivite<br></b></h2> </font>\nEgzersiz: Egzersiz, stresi azaltır ve yoksunluk belirtilerini hafifletir.<br>\nSigarayı bırakmak, sağlık açısından sayısız fayda sağlar ve yaşam kalitesini artırır. Bırakma sürecinde motivasyonunuzu yüksek tutmak ve gerektiğinde profesyonel yardım almak, başarı <br>şansınızı artırır.<br>', NULL);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `contents`
--
ALTER TABLE `contents`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `contents`
--
ALTER TABLE `contents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
