<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Mario Game / Website</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="mario-game">
    <div class="background"></div>
    <div class="foreground"></div>
    <div class="mario"></div>
    <div class="menu">

      <?php
      // Veritabanına bağlanma
      $servername = "localhost";
      $username = "root";
      $password = "";
      $dbname = "mario_website";

      $conn = new mysqli($servername, $username, $password, $dbname);

      if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
      }

      $sql = "SELECT title FROM contents";
      $result = $conn->query($sql);

      if ($result->num_rows > 1) {
        while($row = $result->fetch_assoc()) {
          echo '<div class="option">' . $row["title"] . '</div>';
        }
      } else {
        echo "0 results";
      }

      $conn->close();
      ?>
    </div>
    <div class="content">
    <div class="show first-screen">
      <h2 style="text-align:center;">Bilgilendirme</h2>
      <img style="width:40%; align-items:center; margin-top:0% !important; margin:29%;" src="https://i.hizliresim.com/eb7qglr.png";>
    </div>
      <?php
      // Veritabanına bağlanma
      $conn = new mysqli($servername, $username, $password, $dbname);

      if ($conn->connect_error) {                
        die("Connection failed: " . $conn->connect_error);
      }

      $sql = "SELECT title, content, image_url FROM contents";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
        $index = 0;
        while($row = $result->fetch_assoc()) {
          echo '<div class="content-index-' . $index . '">';
          echo '<h2 style="text-align:center;">' . $row["title"] . '</h2>';
          echo '<p>' . $row["content"] . '</p>';
          if (!empty($row["image_url"])) {
            echo '<img style="width:40%; align-items:center; margin-top:0% !important; margin:29%;" src="' . $row["image_url"] . '" alt="' . $row["title"] . '">';
          }
          echo '</div>';
          $index++;
        }
      } else {
        echo "0 results";
      }

      $conn->close();
      ?>
    </div>
  </div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <script src="js/index.js"></script>
</body>
</html>
