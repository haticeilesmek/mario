<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mario";

// Veritabanı bağlantısını oluştur
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantıyı kontrol et
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['file'])) {
        $target_dir = "./uploads/";
        $target_file = $target_dir . basename($_FILES["file"]["name"]);

        // Dosyayı yükle
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
            echo "Dosya ". htmlspecialchars(basename($_FILES["file"]["name"])). " başarıyla yüklendi.<br>";

            // Veritabanına kaydet
            $filepath = $target_file;
            $sql = "INSERT INTO image (filepath) VALUES ('$filepath')";

            if ($conn->query($sql) === TRUE) {
                echo "Kayıt başarıyla oluşturuldu.<br>";
            } else {
                echo "Kayıt oluşturulurken hata: " . $conn->error . "<br>";
            }
        } else {
            echo "Dosya yüklenirken bir hata oluştu.<br>";
        }
    } else {
        echo "Dosya seçilmedi.<br>";
    }
} else {
    echo "Form gönderilmedi.<br>";
}

$conn->close();
?>
